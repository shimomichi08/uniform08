package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Order;
import bean.Sales;

public class OrderDAO {

	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/uniformdb";
	private static String USER = "root";
	private static String PASS = "root123";

	//データベース接続情報を利用してデータベースに接続するクラスメソッドを定義する
	private static Connection getConnection() {
		try {
			//JDBCドライバーをロードする
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public static void main(String[] args) throws Exception {
		Connection con = getConnection();
		System.out.println("con=" + con);
		con.close();
	}

	public void insert(Order order) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "INSERT INTO orderinfo(orderNo,uniName,uniSize,quantity,uniPrice,overview,email,userName,address,orderDate,pay,send,groupNo) VALUES(NULL,'"
					+ order.getUniName() + "','" + order.getUniSize() + "',"
					+ order.getQuantity() + "," + order.getUniPrice() + ",'" + order.getOverview() + "','"
					+ order.getEmail() + "','" + order.getUserName() + "','" + order.getAddress()
					+ "',CURDATE(),'未入金','未発送',"
					+ order.getGroupNo() + ")";
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			int insertIntoCart = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public ArrayList<Order> showOrderList() {
		Connection con = null;
		Statement smt = null;

		ArrayList<Order> order_list = new ArrayList<Order>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT orderNo, userName, uniName,quantity,uniPrice, uniSize,orderDate,pay,send,groupNo FROM orderinfo ORDER BY orderNo";
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Order order = new Order();
				order.setOrderNo(rs.getInt("orderNo"));
				order.setUserName(rs.getString("userName"));
				order.setUniName(rs.getString("uniName"));
				order.setQuantity(rs.getInt("quantity"));
				order.setUniPrice(rs.getInt("uniPrice"));
				order.setUniSize(rs.getString("uniSize"));
				order.setOrderDate(rs.getString("orderDate"));
				order.setPay(rs.getString("pay"));
				order.setSend(rs.getString("send"));
				order.setGroupNo(rs.getInt("groupNo"));
				order_list.add(order);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order_list;
	}

	//入金状況と発送状況の更新時の対象を見つける
	public Order selectByOrderNo(int orderNo) {
		Connection con = null;
		Statement smt = null;

		Order order = new Order();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT orderDate,orderNo,uniName,userName,uniSize,quantity,uniPrice,pay,send, FROM orderinfo WHERE orderNo = "
					+ orderNo;
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			ResultSet rs = smt.executeQuery(sql);
			while (rs.next()) {
				order.setOrderDate(rs.getString("orderDate"));
				order.setOrderNo(rs.getInt("orderNo"));
				order.setUserName(rs.getString("userName"));
				order.setUniName(rs.getString("uniName"));
				order.setUniSize(rs.getString("uniSize"));
				order.setQuantity(rs.getInt("quantity"));
				order.setUniPrice(rs.getInt("uniPrice"));
				order.setPay(rs.getString("pay"));
				order.setSend(rs.getString("send"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order;
	}

	public void updatePay(int groupNo) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "UPDATE orderinfo SET pay='入金済み' WHERE groupNo=" + groupNo;

			//executeUpdate（）メソッドを利用してSQL文を発行し書籍データを更新する
			int updateBook = smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public void updateSend(int groupNo) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "UPDATE orderinfo SET send= '発送済み' WHERE groupNo=" + groupNo;

			//executeUpdate（）メソッドを利用してSQL文を発行し書籍データを更新する
			int updateBook = smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public Order showOrderDetail(int orderNo) {
		Connection con = null;
		Statement smt = null;

		Order order = new Order();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT orderNo, userName,address,email,uniName,quantity,uniSize,uniPrice, orderDate,pay,send,overview FROM orderinfo WHERE orderNo='"
					+ orderNo + "'";
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				order.setOrderNo(rs.getInt("orderNo"));
				order.setUserName(rs.getString("userName"));
				order.setAddress(rs.getString("address"));
				order.setEmail(rs.getString("email"));
				order.setUniName(rs.getString("uniName"));
				order.setQuantity(rs.getInt("quantity"));
				order.setUniSize(rs.getString("uniSize"));
				order.setUniPrice(rs.getInt("uniPrice"));
				order.setOrderDate(rs.getString("orderDate"));
				order.setPay(rs.getString("pay"));
				order.setSend(rs.getString("send"));
				order.setOverview(rs.getString("overview"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order;
	}

	public ArrayList<Order> selectByUser(String email) {
		Connection con = null;
		Statement smt = null;

		ArrayList<Order> order_list = new ArrayList<Order>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT orderDate,uniName,uniSize,quantity,pay,send FROM orderinfo"
					+ " WHERE email = '" + email + "'";
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Order order = new Order();
				order.setOrderDate(rs.getString("orderDate"));
				order.setUniName(rs.getString("uniName"));
				order.setUniSize(rs.getString("uniSize"));
				order.setQuantity(rs.getInt("quantity"));
				order.setPay(rs.getString("pay"));
				order.setSend(rs.getString("send"));
				order_list.add(order);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order_list;
	}

	public ArrayList<Sales> selectBySales(String year, String month) {
		Connection con = null;
		Statement smt = null;

		ArrayList<Sales> sales_list = new ArrayList<Sales>();
		try {
			con = getConnection();
			smt = con.createStatement();

			switch (month) {
			case "10":
			case "11":
			case "12":
				break;
			default:
				month = "0" + month;
			}

			String sql = "SELECT uniName, sum(quantity) as totalQuantity, uniPrice FROM orderinfo WHERE orderDate LIKE '"
					+ year + "-" + month + "%' and send='発送済み' group by uniName";

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Sales sales = new Sales();
				sales.setUniName(rs.getString("uniName"));
				sales.setTotalQuantity(rs.getInt("totalQuantity"));
				sales.setTotalPrice(rs.getInt("uniPrice") * rs.getInt("totalQuantity"));
				sales_list.add(sales);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return sales_list;
	}

	public Order selectByGroupNo(int groupNo) {
		Connection con = null;
		Statement smt = null;

		Order order = new Order();
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT groupNo FROM orderinfo WHERE groupNo =" + groupNo;
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				order.setGroupNo(rs.getInt("groupNo"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order;
	}

	public ArrayList<Order> searchGroupNo(int groupNo) {

		Connection con = null;
		Statement smt = null;

		//①
		ArrayList<Order> orderList = new ArrayList<Order>();
		try {

			//②
			String sql = "SELECT orderNo,groupNo,userName,uniName,quantity,uniPrice,uniSize,email,orderDate,pay,send FROM orderinfo " +
					"WHERE groupNo= " + groupNo;

			// DBに接続
			//③
			con = getConnection();
			//④
			smt = con.createStatement();

			//⑤
			ResultSet rs = smt.executeQuery(sql);

			//⑥
			while (rs.next()) {
				Order order = new Order();
				order.setOrderNo(rs.getInt("orderNo"));
				order.setGroupNo(rs.getInt("groupNo"));
				order.setUserName(rs.getString("userName"));
				order.setUniName(rs.getString("uniName"));
				order.setQuantity(rs.getInt("quantity"));
				order.setUniPrice(rs.getInt("uniPrice"));
				order.setUniSize(rs.getString("uniSize"));
				order.setEmail(rs.getString("email"));
				order.setOrderDate(rs.getString("orderDate"));
				order.setPay(rs.getString("pay"));
				order.setSend(rs.getString("send"));
				orderList.add(order);

			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return orderList;
	}

}