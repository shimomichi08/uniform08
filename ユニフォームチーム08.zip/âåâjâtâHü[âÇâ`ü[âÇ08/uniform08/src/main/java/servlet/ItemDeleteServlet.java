package servlet;

import java.io.IOException;

import dao.UniformDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/itemDelete")
public class ItemDeleteServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言と初期化
		String error= "";
		
		try {
			//画面から送信されるISBN情報を受け取るためのエンコードを設定する
			response.setContentType("text/html; charset=UTF-8");
			
			UniformDAO uniformDao = new UniformDAO();

			//画面から送信されるISBN情報を受け取る
			int uniNo = Integer.parseInt(request.getParameter("uniNo"));
			
			//書籍情報を削除する
			uniformDao.delete(uniNo);
			
		}catch(IllegalStateException e) {
			error="DB接続エラーの為、書籍削除処理は行えませんでした。";
			request.setAttribute("cmd", "logout");
			
		}finally {
			//エラーがあればエラー画面へ遷移し、なければListServletへフォワードする
			if(error.equals("")) {
				request.getRequestDispatcher("/itemList").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/admin/adminError.jsp").forward(request, response);
			}
		}
	}

}