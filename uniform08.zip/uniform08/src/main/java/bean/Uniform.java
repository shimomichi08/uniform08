package bean;

	public class Uniform {
			private int uniNo;
			private String uniName;
			private String uniSize;
			private int uniStock;
			private int uniPrice;

	public int getUniNo() {
		return uniNo;
	}

	public void setUniNo(int uniNo) {
		this.uniNo = uniNo;
	}
	
	public String getUniName() {
		return uniName;
	}

	public void setUniName(String uniName) {
		this.uniName = uniName;
	}
	
	public String getUniSize() {
		return uniSize;
	}

	public void setUniSize(String uniSize) {
		this.uniSize = uniSize;
	}
	
	public int getUniStock() {
		return uniStock;
	}

	public void setUniStock(int uniStock) {
		this.uniStock = uniStock;
	}
	
	public int getUniPrice() {
		return uniPrice;
	}

	public void setUniPrice(int uniPrice) {
		this.uniPrice = uniPrice;
	}
}
