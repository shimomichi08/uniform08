package bean;

public class Sales {
	private String uniName;
	private int totalQuantity; //ユニフォーム別売上個数
	private int totalPrice; //ユニフォーム別売上金額

	public Sales() {
		uniName = null;
		totalQuantity = 0;
		totalPrice = 0;
	}

	public void setUniName(String uniName) {
		this.uniName = uniName;
	}

	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getUniName() {
		return uniName;
	}

	public int getTotalQuantity() {
		return totalQuantity;
	}

	public int getTotalPrice() {
		return totalPrice;
	}
}
