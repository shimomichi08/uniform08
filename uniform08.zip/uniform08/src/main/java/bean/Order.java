package bean;

	public class Order {
		private int orderNo;
		private String uniName;
		private String uniSize;
		private int quantity;
		private int uniPrice;
		private String overview;
		private String email;
		private String userName;
		private String address;
		private String orderDate;
		private String pay;
		private String send;
		private int groupNo;
	
	public Order() {
		this.orderNo = 0;
		this.uniName = null;
		this.uniSize = null;
		this.quantity = 0;
		this.uniPrice = 0;
		this.overview = null;
		this.email = null;
		this.userName = null;
		this.address = null;
		this.orderDate = null;
		this.pay = null;
		this.send = null;
		this.groupNo=0;
	}
	
	public int getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	
	public String getUniName() {
		return uniName;
	}

	public void setUniName(String uniName) {
		this.uniName = uniName;
	}
	
	public String getUniSize() {
		return uniSize;
	}

	public void setUniSize(String uniSize) {
		this.uniSize = uniSize;
	}
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getUniPrice() {
		return uniPrice;
	}

	public void setUniPrice(int uniPrice) {
		this.uniPrice = uniPrice;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	
	public String getPay() {
		return pay;
	}

	public void setPay(String pay) {
		this.pay = pay;
	}
	
	public String getSend() {
		return send;
	}

	public void setSend(String send) {
		this.send = send;
	}
	
	public int getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(int groupNo) {
		this.groupNo = groupNo;
	}
}