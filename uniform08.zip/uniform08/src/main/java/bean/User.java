package bean;

/**
 * ユーザー情報（ID、名前、パスワード、Eメールアドレス、住所、権限の帰属先）を一つのオブジェクトとしてまとめるためのDTOクラス
 *
 * @author KandaITSchool
 *
 */

public class User {

	/**
	 * ユーザーのID
	 */
	private String userId;
	/**
	 * ユーザーの名前
	 */
	private String userName;
	/**
	 * ユーザーのパスワード
	 */
	private String password;
	/**
	 * ユーザーのEメールアドレス
	 */
	private String email;
	/**
	 * ユーザーの住所
	 */
	private String address;
	/**
	 * 権限の帰属先
	 */
	private String authority;
	/**
	 * コンストラクタ<br>
	 * ユーザー情報（ID、名前、パスワード、Eメールアドレス、住所、権限の帰属先）の初期設定をおこなう
	 */
	public User() {
		this.userId = null;
		this.userName = null;
		this.password = null;
		this.email = null;
		this.address = null;
		this.authority = null;
	}

	/**
	 * ユーザーのIDを取得する
	 *
	 * @return ユーザーのID
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * ユーザーのIDを設定する
	 *
	 * @param userId 設定するユーザーのID
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * ユーザーの名前を取得する
	 *
	 * @return ユーザーの名前
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * ユーザーの名前を設定する
	 *
	 * @param userName 設定するユーザーの名前
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * ユーザーのパスワードを取得する
	 *
	 * @return ユーザーのパスワード
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * ユーザーのパスワードを設定する
	 *
	 * @param password 設定するユーザーのパスワード
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * ユーザーのEメールアドレスを取得する
	 *
	 * @return ユーザーのEメールアドレス
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * ユーザーのEメールアドレスを設定する
	 *
	 * @param email 設定するユーザーのEメールアドレス
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * ユーザーの住所を取得する
	 *
	 * @return ユーザーの住所
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * ユーザーの住所を設定する
	 *
	 * @param address 設定するユーザーの住所
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * 権限の帰属先を取得する
	 *
	 * @return 権限の帰属先
	 */
	public String getAuthority() {
		return authority;
	}

	/**
	 * 権限の帰属先を設定する
	 *
	 * @param authority 設定する権限の帰属先
	 */
	public void setAuthority(String authority) {
		this.authority = authority;
	}

}
