 package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.User;

public class UserDAO {

	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/uniformdb";
	private static String USER = "root";
	private static String PASS = "root123";

	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public ArrayList<User> selectAll() {

		Connection con = null;
		Statement smt = null;

		ArrayList<User> UserList = new ArrayList<User>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT email, password FROM bookinfo ORDER BY isbn";

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User userInfo = new User();
				userInfo.setEmail(rs.getString("email"));
				userInfo.setPassword(rs.getString("password"));
				UserList.add(userInfo);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return UserList;
	}

	public void insertUser(User user) {
		Connection con = null;
		Statement smt = null;

		try {
			String sql = "INSERT INTO bookinfo VALUES('" + user.getEmail() + "','" + user.getPassword() + "')";
			con = getConnection();
			smt = con.createStatement();
			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
	
	public User selectByUser(String email, String password){
		Connection con = null;
		Statement smt = null;
		 
		User user = new User();
		 
		try{
			String sql = "SELECT email, password FROM userinfo WHERE email ='"+email+"' AND password='"+password+"'"; 
			con = getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);
			while(rs.next()) {
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
			}
		 }catch(Exception e){
			throw new IllegalStateException(e);
		 }finally{
		   if( smt != null ){
		       try{smt.close();}catch(SQLException ignore){}
		   }
		   if( con != null ){
		       try{con.close();}catch(SQLException ignore){}
		   }
		 }
		return user;
	}
	
	public void updateUser(User user) {
        Connection con = null;
        Statement smt = null;

        try {
            con = getConnection();
            smt = con.createStatement();

            String sql = "UPDATE bookinfo SET title='"+user.getEmail()+"',price="+user.getPassword()+" WHERE isbn='"+user.getEmail()+"'";

            //executeUpdate（）メソッドを利用してSQL文を発行し書籍データを更新する
            int updateBook = smt.executeUpdate(sql);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        } finally {
            if (smt != null) {
                try {
                    smt.close();
                } catch (SQLException ignore) {
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ignore) {
                }
            }
        }
    }
}