package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.User;

public class UserDAO {

	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/uniformdb";
	private static String USER = "root";
	private static String PASS = "root123";

	/*DB接続*/
	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/*全ユーザー情報を取得するメソッド*/
	public ArrayList<User> selectAll() {

		Connection con = null;
		Statement smt = null;

		ArrayList<User> UserList = new ArrayList<User>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT userId, userName, password, email, address, authority FROM userinfo";

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User userInfo = new User();
				userInfo.setUserId(rs.getString("userId"));
				userInfo.setUserName(rs.getString("userName"));
				userInfo.setPassword(rs.getString("password"));
				userInfo.setEmail(rs.getString("email"));
				userInfo.setAddress(rs.getString("address"));
				userInfo.setAuthority(rs.getString("authority"));
				UserList.add(userInfo);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return UserList;
	}

	/*ユーザー登録メソッド*/
	public void insertUser(User user) {
		Connection con = null;
		Statement smt = null;

		try {
			String sql = "INSERT INTO userinfo(userId,userName,password,email,address,authority) VALUES('"
					+ user.getUserId() + "','" + user.getUserName() + "','" + user.getPassword() + "','"
					+ user.getEmail() + "','" + user.getAddress() + "','" + user.getAuthority() + "')";
			con = getConnection();
			smt = con.createStatement();
			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/*ユーザーIDとパスワードからユーザーを検索するメソッド*/
	public User selectByUser(String userId, String password) {
		Connection con = null;
		Statement smt = null;

		User user = new User();

		try {
			String sql = "SELECT userId, userName, password, email, address, authority FROM userinfo WHERE userId ='"
					+ userId + "' AND password='" + password + "'";
			con = getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);
			while (rs.next()) {
				user.setUserId(rs.getString("userId"));
				user.setUserName(rs.getString("userName"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setAuthority(rs.getString("authority"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;
	}

	public User selectByUser(String userId) {
		Connection con = null;
		Statement smt = null;

		User user = new User();

		try {
			String sql = "SELECT userId, userName, password, email, address, authority FROM userinfo WHERE userId ='"
					+ userId + "'";
			con = getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);
			while (rs.next()) {
				user.setUserId(rs.getString("userId"));
				user.setUserName(rs.getString("userName"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setAuthority(rs.getString("authority"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;
	}

	/*会員情報を更新するメソッド*/
	public void updateUser(User user) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "UPDATE userinfo SET userName='"
					+ user.getUserName() + "',password='" + user.getPassword() +
					"',email='" + user.getEmail() + "',address='" + user.getAddress() + "' "
					+ "WHERE userId='" + user.getUserId() + "' AND authority='" + user.getAuthority() + "'";

			//executeUpdate（）メソッドを利用してSQL文を発行し書籍データを更新する
			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
}