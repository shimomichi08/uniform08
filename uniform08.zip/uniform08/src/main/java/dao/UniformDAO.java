package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Uniform;

public class UniformDAO {

	// DB情報をフィールド変数に定義
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/uniformdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// 情報を元にDB接続を行うメソッド定義
	private static Connection getConnection() {

		try {

			// JDBCドライバーをロードする
			Class.forName(RDB_DRIVE);

			// Connectionオブジェクトを生成する
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);

			// 生成したConnectionオブジェクトをリターンする
			return con;

		} catch (Exception e) {

			throw new IllegalStateException(e);
		} // try-catch
	} // getConnection

	// 全情報を取得
	public ArrayList<Uniform> selectAll() {

		Connection con = null;
		Statement smt = null;

		ArrayList<Uniform> uniList = new ArrayList<Uniform>();

		try {

			// SQL文定義
			String sql = "SELECT uniNo, uniName, uniSize, uniStock, uniPrice FROM uniforminfo ORDER BY uniNo";

			// オブジェクト生成
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// Uniformオブジェクトに格納
			while (rs.next()) {
				Uniform uniform = new Uniform();
				uniform.setUniNo(rs.getInt("uniNo"));
				uniform.setUniName(rs.getString("uniName"));
				uniform.setUniSize(rs.getString("uniSize"));
				uniform.setUniStock(rs.getInt("uniStock"));
				uniform.setUniPrice(rs.getInt("uniPrice"));
				uniList.add(uniform);
			} // while

			// クローズ
			con.close();
			smt.close();

		} catch (Exception e) {

			throw new IllegalStateException(e);

			// リソースの開放
		} finally {

			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			} // if

			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			} // if
		} // if

		return uniList;

	} // selectAll

	// 登録処理
	public void insert(Uniform uniform) {

		Connection con = null;
		Statement smt = null;

		try {

			// SQL文の定義
			String sql = "INSERT INTO uniforminfo(uniNo,uniName,uniSize,uniStock,uniPrice) VALUES" + "(" + uniform.getUniNo() + ","
					+ "'" + uniform.getUniName() + "'," + " ' " + uniform.getUniSize() + "',"
					+ " " + uniform.getUniStock() + "," + "" + uniform.getUniPrice() + ")";

			// オブジェクト生成
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			smt.executeUpdate(sql);

			// クローズ
			con.close();
			smt.close();

		} catch (Exception e) {

			throw new IllegalStateException(e);

			// リソースの開放
		} finally {

			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			} // if

			if (con != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			} // if
		} // finally
	} // insert

	//削除処理
	public void delete(int uniNo) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "DELETE FROM uniforminfo WHERE uniNo = " + uniNo;
			//executeUpdate（）メソッドを利用してSQL文を発行し書籍データを削除する
			int deleteBook = smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
	
	// 更新処理
	public void update(Uniform uniform) {

		Connection con = null;
		Statement smt = null;

		try {

			// SQL文定義
			String sql = "UPDATE uniforminfo SET " + "uniName = '" + uniform.getUniName() + "', "
					+ "uniSize = '" + uniform.getUniSize() + "', " + "uniStock =  " + uniform.getUniStock() + ","
					+ "uniPrice = " + uniform.getUniPrice() + " WHERE uniNo = " + uniform.getUniNo() + "";

			// オブジェクト生成
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			smt.executeUpdate(sql);

			// クローズ
			con.close();
			smt.close();

		} catch (Exception e) {

			throw new IllegalStateException(e);

			// リソースの開放
		} finally {

			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			} // if

			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			} // if
		} // if
	} // update

	// データ検索
	public Uniform selectByuniNo(String uniNo) {

		Connection con = null;
		Statement smt = null;

		// オブジェクト生成
		Uniform uniform = new Uniform();

		try {

			// SQL文定義
			String sql = "SELECT uniNo, uniName, uniSize, uniStock, uniPrice FROM uniforminfo WHERE uniNo = " + uniNo + "";

			// オブジェクト生成
			con = getConnection();
			smt = con.createStatement();

			// SQL文定義
			ResultSet rs = smt.executeQuery(sql);

			// uniformオブジェクトに格納
			while(rs.next()) {
				uniform.setUniNo(rs.getInt("uniNo"));
				uniform.setUniName(rs.getString("uniName"));
				uniform.setUniSize(rs.getString("uniSize"));
				uniform.setUniStock(rs.getInt("uniStock"));
				uniform.setUniPrice(rs.getInt("uniPrice"));
			} // while

			// クローズ
			con.close();
			smt.close();

		} catch (Exception e) {

			throw new IllegalStateException(e);

			// リソースの開放
		} finally {

			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			} // if

			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			} // if
		} // if
		return uniform;
	} // selectByuniNo
} // class
