package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Order;

public class OrderDAO {

	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/uniformdb";
	private static String USER = "root";
	private static String PASS = "root123";

	//データベース接続情報を利用してデータベースに接続するクラスメソッドを定義する
	private static Connection getConnection() {
		try {
			//JDBCドライバーをロードする
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public static void main (String[] args) throws Exception {
		Connection con = getConnection();
		System.out.println("con=" + con);
		con.close();
	}
	
	public void insert(Order order) {
		Connection con = null;
		Statement smt = null;
		
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "INSERT INTO orderinfo VALUES(NULL,'"+ order.getUserId() + "','"+ order.getUniNo() +"',"
					+ order.getUniName() + "','"+ order.getQuantity() + "','"+ order.getOverview() + "','"
					+ order.getUniPrice() +",CURDATE()"+ order.getPay() + "','"+ order.getSend()+")";
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			int insertIntoCart = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
	
	public ArrayList<Order> selectAll() {
		Connection con = null;
		Statement smt = null;
		
		ArrayList<Order> order_list = new ArrayList<Order>();
		
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT orderNo, userName, uniName,quantity,uniPrice, orderDate,pay,send FROM orderinfo ORDER BY orderNo";
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			ResultSet rs = smt.executeQuery(sql);
			
			while (rs.next()) {
				Order order = new Order();
				order.setOrderNo(rs.getInt("orderNo"));
				order.setUserName(rs.getString("userName"));
				order.setUniName(rs.getString("uniName"));
				order.setQuantity(rs.getInt("quantity"));
				order.setUniPrice(rs.getInt("uniPrice"));
				order.setOrderDate(rs.getString("orderDate"));
				order.setPay(rs.getString("pay"));
				order.setSend(rs.getString("send"));
				order_list.add(order);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order_list;
	}
	
	public void updatePay(Order order) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "UPDATE orderinfo SET pay='"+order.getPay()+" WHERE orderNo='"+order.getOrderNo()+"'";

			//executeUpdate（）メソッドを利用してSQL文を発行し書籍データを更新する
			int updateBook = smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
	
	public void updateSend(Order order) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "UPDATE orderinfo SET send='"+order.getSend()+" WHERE orderNo='"+order.getOrderNo()+"'";

			//executeUpdate（）メソッドを利用してSQL文を発行し書籍データを更新する
			int updateBook = smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
	
	public ArrayList<Order> selectByUser(String userId) {
		Connection con = null;
		Statement smt = null;
		
		ArrayList<Order> order_list = new ArrayList<Order>();
		
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT orderDate,uniName,uniSize,quantity,pay,send FROM orderinfo"
					+ " WHERE userId = '"+userId+"'";
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			ResultSet rs = smt.executeQuery(sql);
			
			while (rs.next()) {
				Order order = new Order();
				order.setOrderDate(rs.getString("user"));
				order.setUniName(rs.getString("title"));
				order.setUniSize(rs.getString("date"));
				order.setQuantity(rs.getInt("quantity"));
				order.setPay(rs.getString("pay"));
				order.setSend(rs.getString("send"));
				order_list.add(order);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order_list;
	}
	
	
	
	
	
	public ArrayList<Order> showOrderDetail(int orderNo) {
		Connection con = null;
		Statement smt = null;
		
		ArrayList<Order> order_list = new ArrayList<Order>();
		
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT orderNo, userName, uniName,address,email,uniName,quantity,uniSize,(uniPrice*quantity), orderDate,pay,send FROM orderinfo WHERE orderNo='"+orderNo+"'";
			//executeUpdate（）メソッドを利用してSQL文を発行しDBに登録する
			ResultSet rs = smt.executeQuery(sql);
			
			while (rs.next()) {
				Order order = new Order();
				//orderに各要素をsetする
				order.setOrderNo(rs.getInt("orderNo"));
				order.setUserName(rs.getString("userName"));
				order.setUniName(rs.getString("uniName"));
				order.setAddress(rs.getString("address"));
				order.setEmail
				order_list.add(order);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order_list;
	}
	
	
}