package util;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {
	public void buyEmail(String userName, String mail_detail, int total) {
		//購入時のメール
		try {
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(
					props,
					new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							//メールサーバにログインするメールアドレスとパスワードを設定
							return new PasswordAuthentication("test.sender@kanda-it-school-system.com",
									"kandaSender202208");
						}
					});

			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage.setFrom(
					new InternetAddress("system.project.team21@kanda-it-school-system.com", "株式会社神田ユニフォーム", "iso-2022-jp"));

			// 送信先メールアドレスを指定（下道のメールに飛びます。）
			mimeMessage.setRecipients(Message.RecipientType.TO, "t-shimomichi@sr-net.co.jp\n");

			// メールのタイトルを指定
			mimeMessage.setSubject("【株式会社神田ユニフォーム】商品のご購入ありがとうございました\n", "iso-2022-jp");

			// メールの内容を指定
			String str = "※このメールは配信専用のアドレスで自動配信にてお送りさせていただいております。このメールアドレスに返信いただいてもご返事ができません。\n"
					+ "\n"
					+ userName +"様\n"
					+ "\n"
					+ "この度は『株式会社神田ユニフォーム』をご利用いただきまして誠にありがとうございます。\n"
					+ "まず心より御礼申し上げます。\n"
					+ "\n"
					+ "☆ご注文に関するお問い合わせ\n"
					+ "お問い合わせの際には「お問い合わせ番号」または「ご注文番号」をご連絡ください。\n"
					+ "お問い合わせ番号：【000-0000-0000】をご連絡ください。\n"
					+ "\n"
					+ "■商品手配状況・入金状況・発送状況・について\n"
					+ "\n"
					+ "入金状況につきましては、入金が確認でき次第、メールでお知らせいたします。\n"
					+ "発送状況につきましては、こちらが発送が完了でき次第、メールでお知らせいたします。\n"
					+ "\n"
					+ "ご注文いただきました内容は、以下の通りでございますのでご確認くださいませ。\n"
					+ "\n"
					+ "■ご注文内容\n"
					+ "\n"
					+ "--------------------------------------------------"
					+ mail_detail 
					+ "--------------------------------------------------\n"
					+ "合計:" + total +"円\n"
					+ "==================================================\n"
					+ "\n"
					+ "今回お支払い予定金額:" + total + "円\n"
					+ "\n"
					+ "==================================================\n"
					+ "-----------------------------------------------------------------------------------------------\n"
					+ "★ご注意：\n"
					+ "このEメールは配信専用となっております。\n"
					+ "このメールアドレスにご返信いただいてもご返事ができません。\n"
					+ "-----------------------------------------------------------------------------------------------\n"
					+ "\n"
					+ "この度はご注文いただき誠にありがとうございました。\n"
					+ "スタッフ一同、改めて御礼申し上げます。\n"
					+ "\n"
					+ "今後とも【株式会社神田ユニフォーム】を何卒よろしくお願いいたします。\n"
					+ "\n"
					+ "-----------------------------------------------------------------------------------------------\n"
					+ "\n"
					+ "============================================================\n"
					+ "もし、このようなご購入の手続きをした覚えがない場合は、大変お手数ですが、このメールの全文と＜購入手続きをした覚えがない>旨を必ず一文添えていただき「 メールアドレス」に送付ください。\n"
					+ "============================================================\n";

			mimeMessage.setText(str, "iso-2022-jp");

			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("購入送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("購入送信に失敗しました。\n" + e);
		}
	}

	public void payEmail(String userName, String mail_detail, int total) {
		//入金時のメール
		try {
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(
					props,
					new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							//メールサーバにログインするメールアドレスとパスワードを設定
							return new PasswordAuthentication("test.sender@kanda-it-school-system.com",
									"kandaSender202208");
						}
					});

			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage.setFrom(
					new InternetAddress("system.project.team21@kanda-it-school-system.com", "株式会社神田ユニフォーム", "iso-2022-jp"));

			// 送信先メールアドレスを指定（廣野のメールに飛びます。）
			mimeMessage.setRecipients(Message.RecipientType.TO, "y-hirono@sr-net.co.jp\n");

			// メールのタイトルを指定
			mimeMessage.setSubject("【株式会社神田ユニフォーム】ご入金のお礼と商品の発送手配について", "iso-2022-jp");

			// メールの内容を指定
			String str = "※このメールは配信専用のアドレスで自動配信にてお送りさせていただいております。このメールアドレスに返信いただいてもご返事ができません。\n"
					+ "\n"
					+ userName+ "様\n"
					+ "\n"
					+ "先日は当店をご利用いただき誠にありがとうございます。\n"
					+ "\n"
					+ "この度は早速、ご入金を頂きましてありがとうございます。\n"
					+ "早速商品の発送の手続きをさせて頂きます。\n"
					+ "\n"
					+ "■発送状況\n"
					+ "\n"
					+ "発送状況につきましては、こちらが発送が完了でき次第、メールでお知らせいたします。\n"
					+ "\n"
					+ "今回のご注文内容は下記の通りです。\n"
					+ "\n"
					+ "■ご注文内容\n"
					+ "\n"
					+ "ご注文日:○○〇\n"
					+ "--------------------------------------------------"
					+ mail_detail
					+ "--------------------------------------------------\n"
					+ "合計:"+ total + "円\n"
					+ "==================================================\n"
					+ "\n"
					+ "今回お支払い予定金額:"+ total +"円\n"
					+ "\n"
					+ "==================================================\n"
					+ "-----------------------------------------------------------------------------------------------\n"
					+ "★ご注意：\n"
					+ "このEメールは配信専用となっております。\n"
					+ "このメールアドレスにご返信いただいてもご返事ができません。\n"
					+ "-----------------------------------------------------------------------------------------------\n"
					+ "\\n\n"
					+ "この度はご注文いただき誠にありがとうございました。\n"
					+ "スタッフ一同、改めて御礼申し上げます。\n"
					+ "\\n\n"
					+ "今後とも【株式会社神田ユニフォーム】を何卒よろしくお願いいたします。\n"
					+ "\n"
					+ "-----------------------------------------------------------------------------------------------\n"
					+ "\n"
					+ "============================================================\n"
					+ "もし、このようなご購入の手続きをした覚えがない場合は、大変お手数ですが、このメールの全文と＜購入手続きをした覚えがない>旨を必ず一文添えていただき「 メールアドレス」に送付ください。\n"
					+ "============================================================\n";

			mimeMessage.setText(str, "iso-2022-jp");

			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("入金送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("入金送信に失敗しました。\n" + e);
		}
	}

	public void beanEmail(String userName, String mail_detail, int total) {
		//発送時のメール
		try {
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(
					props,
					new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							//メールサーバにログインするメールアドレスとパスワードを設定
							return new PasswordAuthentication("test.sender@kanda-it-school-system.com",
									"kandaSender202208");
						}
					});

			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage.setFrom(
					new InternetAddress("system.project.team21@kanda-it-school-system.com", "株式会社神田ユニフォーム", "iso-2022-jp"));

			// 送信先メールアドレスを指定（廣野のメールに飛びます。）
			mimeMessage.setRecipients(Message.RecipientType.TO, "y-hirono@sr-net.co.jp\n");

			// メールのタイトルを指定
			mimeMessage.setSubject("【株式会社神田ユニフォーム】商品の発送完了のご報告\n", "iso-2022-jp");

			// メールの内容を指定
			String str = "※このメールは配信専用のアドレスで自動配信にてお送りさせていただいております。このメールアドレスに返信いただいてもご返事ができません。\n"
					+ "\n"
					+ userName+"様\n"
					+ "\n"
					+ "先日は当店をご利用いただき誠にありがとうございました。\n"
					+ "\n"
					+ "ご注文いただきました商品の発送が完了いたしましたのでご連絡いたします。\n"
					+ "\n"
					+ "お荷物の配送状況を以下から確認していただけます。\n"
					+ "お荷物伝票番号を入力して発送状況をご確認ください。\n"
					+ "\n"
					+ "■お荷物伝票番号\n"
					+ "--------------------------------------------------\n"
					+ "[お荷物伝票番号]○○○○○○○○○○○\n"
					+ "[配送方法]ヤマト運輸\n"
					+ "--------------------------------------------------\n"
					+ "\n"
					+ "※お荷物伝票番号を確認されるタイミングによっては、\n"
					+ "  まだお荷物伝票番号がシステムに反映されていない場合がございます。\n"
					+ "  お時間をあけてから再度ご確認下さいますようお願いいたします。\n"
					+ "\n"
					+ "■商品の追跡URL\n"
					+ "----------------------------------------------------------------\n"
					+ "ヤマト運輸\n"
					+ "  ⇒http://toi.kuronekoyamato.co.jp/cgi-bin/tneko\n"
					+ "-----------------------------------------------------------------\n"
					+ "\n"
					+ "今回のご注文内容は下記の通りです。\n"
					+ "\n"
					+ "■ご注文内容\n"
					+ "\n"
					+ "ご注文日:○○〇\n"
					+ "--------------------------------------------------"
					+ mail_detail
					+ "--------------------------------------------------\n"
					+ "小計:"+ total +"\n"
					+ "==================================================\n"
					+ "\n"
					+ "今回お支払い予定金額:"+ total +"\n"
					+ "\n"
					+ "==================================================\n"
					+ "-----------------------------------------------------------------------------------------------\n"
					+ "★ご注意：\n"
					+ "このEメールは配信専用となっております。\n"
					+ "このメールアドレスにご返信いただいてもご返事ができません。\n"
					+ "-----------------------------------------------------------------------------------------------\n"
					+ "\n"
					+ "※天候・交通状況により、入荷が遅れ発送日が変更となる場合ございます。\n"
					+ "  予めご了承頂きますようお願い致します。\n"
					+ "\n"
					+ "商品到着まで今しばらくお待ちくださいませ。\n"
					+ "どうぞよろしくお願い申し上げます。\n"
					+ "\n"
					+ "今後とも【株式会社神田ユニフォーム】を何卒よろしくお願いいたします。\n"
					+ "\n"
					+ "-----------------------------------------------------------------------------------------------\n"
					+ "\n"
					+ "============================================================\n"
					+ "もし、このようなご購入の手続きをした覚えがない場合は、大変お手数ですが、このメールの全文と＜購入手続きをした覚えがない>旨を必ず一文添えていただき「 メールアドレス」に送付ください。\n"
					+ "============================================================\n";

			mimeMessage.setText(str, "iso-2022-jp");

			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("発送送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("発送送信に失敗しました。\n" + e);
		}
	}
}
