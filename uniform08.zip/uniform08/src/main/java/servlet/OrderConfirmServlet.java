package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import dao.OrderDAO;
import dao.UniformDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.SendMail;


@WebServlet("/orderConfirm")
@SuppressWarnings("unchecked")
public class OrderConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		
		//TODO 例外処理を作る
		
		String error = "";
		
		HttpSession session = request.getSession();
		
		try {
			response.setContentType("text/html; charset=UTF-8");
			
			ArrayList<Order> orderList = (ArrayList<Order>)session.getAttribute("orderList");
			if (orderList == null) {
				error = "session";
				return;
			}
			OrderDAO orderDao = new OrderDAO();
			UniformDAO uniDao = new UniformDAO();
			int total = 0;
			String mail_detail = "";
			
			for (int i = 0; i < orderList.size(); i++) {
				Order order=orderList.get(i);
				orderDao.insert(order);
				uniDao.stockUpdate(order.getUniName(), order.getUniSize(), order.getQuantity());
				
				mail_detail = mail_detail + "\n【商品名】" + order.getUniName() + "\n【サイズ】" + order.getUniSize()
						+ "\n【単価】" + order.getUniPrice()+ "\n【個数】" + order.getQuantity()
						+ "\n【小計】" + (order.getUniPrice()*order.getQuantity()) +"\n";
				total += order.getUniPrice()*order.getQuantity();
				
				if(i == orderList.size()-1) {
					mail_detail = mail_detail + "\n【備考欄】" + order.getOverview() + "\n";
				}
			}
			
			SendMail sm = new SendMail();
			sm.buyEmail(orderList.get(0).getUserName(),mail_detail,total);
			
		}catch(IllegalStateException e) {
			error="db";
		}finally {
			session.removeAttribute("orderList");
			if(error.equals("")) {
				request.getRequestDispatcher("/view/user/orderBuyConfirm.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/user/userError.jsp").forward(request, response);
			}
		}	
	}
}