package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/orderConfirm")
@SuppressWarnings("unchecked")
public class OrderConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		
		//TODO 例外処理を作る
		
		String error = "";
		
		HttpSession session = request.getSession();
		
		try {
			response.setContentType("text/html; charset=UTF-8");
			
			//TODO ここにメール機能を追加する
			
			ArrayList<Order> orderList = (ArrayList<Order>)session.getAttribute("orderList");
			OrderDAO orderDao = new OrderDAO();
			
			for (int i = 0; i < orderList.size(); i++) {
				orderDao.insert(orderList.get(i));
			}
			
		}catch(IllegalStateException e) {
			error="DB接続エラーの為、購入は出来ません。";
			request.setAttribute("cmd", "logout");
		
		}finally {
			session.removeAttribute("orderList");
			if(error.equals("")) {
				request.getRequestDispatcher("/view/user/orderBuyConfirm.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}	
	}
}