package servlet;

import java.io.IOException;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.SendMail;


@WebServlet("/orderConfirm")
public class OrderConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String error = "";
		
		try {
			response.setContentType("text/html; charset=UTF-8");
			
			int orderNo = Integer.parseInt(request.getParameter("orderNo"));
			String uniName = request.getParameter("uniName");
			String uniSize = request.getParameter("uniSize");
			int quantity = Integer.parseInt(request.getParameter("quantity"));
			int uniPrice = Integer.parseInt(request.getParameter("uniPrice"));
			String overview = request.getParameter("overview");
			String email = request.getParameter("email");
			String userName = request.getParameter("userName");
			String address = request.getParameter("address");
			String orderDate = request.getParameter("orderDate");
			String pay = request.getParameter("pay");
			String send = request.getParameter("send");
			
			Order order = new Order();
			OrderDAO orderDao = new OrderDAO();
			
			order.setOrderNo(orderNo);
			order.setUniName(uniName);
			order.setUniSize(uniSize);
			order.setQuantity(quantity);
			order.setUniPrice(uniPrice);
			order.setOverview(overview);
			order.setEmail(email);
			order.setUserName(userName);
			order.setAddress(address);
			order.setOrderDate(orderDate);
			order.setPay(pay);
			order.setSend(send);

			orderDao.insert(order);
			
			int total = 0;
			String mail_detail = "";
				
			mail_detail = mail_detail + "\n" + order.getOrderNo() +" " + order.getUniName() + " " + order.getUniSize() + " ";
			total += order.getUniPrice()*order.getQuantity();

			//リクエストスコープへ登録する
			request.setAttribute("book_list", book_list);
			
			SendMail sm = new SendMail();
			sm.orderedMail (order.getUserName(),mail_detail,total);
			
		}catch(IllegalStateException e) {
			error="DB接続エラーの為、購入は出来ません。";
			request.setAttribute("cmd", "logout");
		
		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}	
	}
}