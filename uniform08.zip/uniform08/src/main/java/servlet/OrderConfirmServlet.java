package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.SendMail;


@WebServlet("/orderConfirm")
@SuppressWarnings("unchecked")
public class OrderConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		
		//TODO 例外処理を作る
		
		String error = "";
		
		HttpSession session = request.getSession();
		
		try {
			response.setContentType("text/html; charset=UTF-8");
			
			ArrayList<Order> orderList = (ArrayList<Order>)session.getAttribute("orderList");
			OrderDAO orderDao = new OrderDAO();
			
			int total = 0;
			String mail_detail = "";
			
			for (int i = 0; i < orderList.size(); i++) {
				orderDao.insert(orderList.get(i));
				
				mail_detail = mail_detail + "\n【商品名】" + orderList.get(i).getUniName() + "\n【サイズ】" + orderList.get(i).getUniSize()
						+ "\n【単価】" + orderList.get(i).getUniPrice()+ "\n【個数】" + orderList.get(i).getQuantity()
						+ "\n【小計】" + (orderList.get(i).getUniPrice()*orderList.get(i).getQuantity()) +"\n";
				total += orderList.get(i).getUniPrice()*orderList.get(i).getQuantity();
				
				if(i == orderList.size()-1) {
					mail_detail = mail_detail + "\n【備考欄】" + orderList.get(i).getOverview() + "\n";
				}
			}
			
			SendMail sm = new SendMail();
			sm.buyEmail(orderList.get(0).getUserName(),mail_detail,total);
			
		}catch(IllegalStateException e) {
			error="DB接続エラーの為、購入は出来ません。";
			request.setAttribute("cmd", "logout");
		
		}finally {
			session.removeAttribute("orderList");
			if(error.equals("")) {
				request.getRequestDispatcher("/view/user/orderBuyConfirm.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}	
	}
}