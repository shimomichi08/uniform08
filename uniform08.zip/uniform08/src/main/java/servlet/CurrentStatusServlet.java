package servlet;

import java.io.IOException;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/currentStatus")
public class CurrentStatusServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言と初期化
		String error = "";

		OrderDAO orderObj = new OrderDAO();

		request.setCharacterEncoding("UTF-8");

		int orderNo = Integer.parseInt(request.getParameter("orderNo"));
		try {

			Order order = orderObj.selectByOrderNo(orderNo);
			if (order.getOrderNo() == 0) {
				error = "更新対象の履歴が存在しない為、変更画面は表示できませんでした。";
				return;
			}

			//リクエストスコープに登録
			request.setAttribute("order_list", order);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			request.setAttribute("cmd", "logout");

		} finally {
			//エラーがあればエラー画面へ遷移し、なければlist.jspへフォワードする
			if (error.equals("")) {
				request.getRequestDispatcher("/view/admin/currentStatus.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
