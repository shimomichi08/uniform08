package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/currentStatus")
public class CurrentStatusServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言と初期化
		String error = "";

		OrderDAO orderObj = new OrderDAO();

		request.setCharacterEncoding("UTF-8");

		int groupNo = Integer.parseInt(request.getParameter("groupNo"));
		try {

			ArrayList<Order> orderList = orderObj.searchGroupNo(groupNo);
			
			if (orderList.get(0).getGroupNo() == 0) {
				error = "更新対象の履歴が存在しない為、変更画面は表示できませんでした。";
				return;
			}

			//リクエストスコープに登録
			request.setAttribute("orderList", orderList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			request.setAttribute("cmd", "logout");

		} finally {
			//エラーがあればエラー画面へ遷移し、なければlist.jspへフォワードする
			if (error.equals("")) {
				request.getRequestDispatcher("/view/admin/currentStatus.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/admin/adminError.jsp").forward(request, response);
			}
		}
	}
}
