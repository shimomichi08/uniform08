package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Uniform;
import dao.UniformDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/itemList")
public class ItemListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言
		String error = null;
		UniformDAO uniformDao=new UniformDAO();
		try {
			//一覧を取得する
			ArrayList<Uniform> UniList=uniformDao.selectAll();
			//取得した詳細情報をリクエストスコープに登録
			request.setAttribute("UniList", UniList);
		} catch (IllegalStateException e) {
			error = "接続エラーの為、一覧表示は行えませんでした。";
			request.setAttribute("cmd", "logout");
		} finally {
			//詳細画面に遷移
			if (error == null) {
				request.getRequestDispatcher("/view/admin/itemList.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/admin/adminError.jsp").forward(request, response);
			}
		}
	}
}
