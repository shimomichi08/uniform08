package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/orderList")
public class OrderListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言と初期化
		String error = "";
		try {
			OrderDAO orderDao = new OrderDAO();
			ArrayList<Order> orderList = new ArrayList<Order>();

			//書籍情報を取得する
			orderList = orderDao.showOrderList();
			//取得した書籍情報をbook_listという名前でリクエストスコープに登録
			request.setAttribute("order_list", orderList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			request.setAttribute("cmd", "logout");

		} finally {
			//エラーがあればエラー画面へ遷移し、なければlist.jspへフォワードする
			if (error.equals("")) {
				request.getRequestDispatcher("/view/admin/orderList.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}