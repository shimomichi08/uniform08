package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

import bean.Order;
import bean.Sales;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/orderList")
public class OrderListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言と初期化
		String error = "";
		try {
			//月別売り上げ
			OrderDAO orderDao = new OrderDAO();
			Calendar cal = Calendar.getInstance();
			int nowYear = cal.get(Calendar.YEAR);
			int nowMonth = (cal.get(Calendar.MONTH) + 1);
			int nowTotal = 0;
			String strNowYear = nowYear + "";
			String strNowMonth = nowMonth + "";
			ArrayList<Sales> nowSalesList = orderDao.selectBySales(strNowYear, strNowMonth);
			for (int i = 0; i < nowSalesList.size(); i++) {
				Sales sales = nowSalesList.get(i);
				nowTotal += sales.getTotalPrice();
			}
			Calendar cal2 = Calendar.getInstance();
			cal2.set(Calendar.MONTH, cal.get(Calendar.MONTH) - 1);
			int beforeYear = cal2.get(Calendar.YEAR);
			int beforeMonth = (cal2.get(Calendar.MONTH) + 1);
			int beforeTotal = 0;
			String strBeforeYear = beforeYear + "";
			String strBeforeMonth = beforeMonth + "";
			ArrayList<Sales> beforeSalesList = orderDao.selectBySales(strBeforeYear, strBeforeMonth);
			for (int i = 0; i < beforeSalesList.size(); i++) {
				Sales sales = beforeSalesList.get(i);
				beforeTotal += sales.getTotalPrice();
			}
			request.setAttribute("nowTotal", nowTotal);
			request.setAttribute("beforeTotal", beforeTotal);
			
			ArrayList<Order> orderList = new ArrayList<Order>();

			orderList = orderDao.showOrderList();
			//取得した書籍情報をbook_listという名前でリクエストスコープに登録
			request.setAttribute("orderList", orderList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			request.setAttribute("cmd", "logout");

		} finally {
			//エラーがあればエラー画面へ遷移し、なければlist.jspへフォワードする
			if (error.equals("")) {
				request.getRequestDispatcher("/view/admin/orderList.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}