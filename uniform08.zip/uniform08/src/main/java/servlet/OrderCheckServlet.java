package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import bean.Uniform;
import bean.User;
import dao.OrderDAO;
import dao.UniformDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/orderCheck")
public class OrderCheckServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		/*エラーメッセージの宣言
		  (error:エラー画面に遷移するエラー、message:登録フォームに戻るエラー)*/
		String error = null;
		String message1 = null;
		String message2 = null;
		String message3 = null;
		String message4 = null;
		String message5 = null;
		int count = 0;

		//各種変数宣言
		String[] uniName = request.getParameterValues("uniName[]");
		String[] uniSize = request.getParameterValues("uniSize[]");
		String[] quantity = request.getParameterValues("quantity[]");
		int uniPrice = Integer.parseInt(request.getParameter("uniPrice"));
		String overview = request.getParameter("overview");
		String email = request.getParameter("email");
		String userName = request.getParameter("userName");
		String address = request.getParameter("address");
		String message = request.getParameter("message");
		OrderDAO orderDao = new OrderDAO();
		UniformDAO uniDao = new UniformDAO();

		int groupNo;
		while (true) {
			groupNo = (int) (Math.random() * 10000) + 1;
			if (orderDao.selectByGroupNo(groupNo).getGroupNo() == 0) {
				break;
			}
		}

		//備考欄が空白なら「なし」とする
		if ("".equals(message)) {
			message = "なし";
		}

		ArrayList<Order> orderList = new ArrayList<Order>();

		try {
			response.setContentType("text/html; charset=UTF-8");
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");
			
			if(user == null){
				//セッション切れならerror.jspへフォワードする
				error = "session";
				return;
			}

			for (int i = 0; i < uniName.length; i++) {
				if (quantity[i].equals("")) {
					message4 = "希望個数を入力してください";
					request.setAttribute("message4", message4);
					count++;
					break;
				}
				Uniform uniform = uniDao.organize(uniName[i], uniSize[i]);
				if (uniform.getUniStock() < Integer.parseInt(quantity[i])) {
					message4 = "在庫数を上回っています。(在庫数：" + uniform.getUniStock() + ")";
					request.setAttribute("message4", message4);
					count++;
					break;
				}

				Order order = new Order();
				order.setUniName(uniName[i]);
				order.setUniSize(uniSize[i]);
				order.setQuantity(Integer.parseInt(quantity[i]));
				order.setUniPrice(uniPrice);
				order.setOverview(overview);
				order.setEmail(email);
				order.setUserName(userName);
				order.setAddress(address);
				order.setOverview(message);
				order.setGroupNo(groupNo);
				orderList.add(order);
				if (quantity[i].equals("")) {
					message4 = "希望個数を入力してください";
					request.setAttribute("message4", message4);
					count++;
				}
			}
			if (email.equals("")) {
				message1 = "メールアドレスを入力してください";
				request.setAttribute("message1", message1);
				count++;
			}
			if (userName.equals("")) {
				message2 = "氏名を入力してください";
				request.setAttribute("message2", message2);
				count++;
			}
			if (address.equals("")) {
				message3 = "住所を入力してください";
				request.setAttribute("message3", message3);
				count++;
			}
			if (count > 0) {
				return;
			}

			//セッションにorderListを登録
			session.setAttribute("orderList", orderList);

		} catch (IllegalStateException e) {
			error = "db";
		} catch (NumberFormatException e) {
			message5 = "購入個数には数値を入力してください。";
			request.setAttribute("message5", message5);
			count++;
		}finally {
			if (count > 0) {
				//リクエストスコープに入力情報を格納
				request.setAttribute("uniName[]", uniName);
				request.setAttribute("uniSize[]", uniSize);
				request.setAttribute("quantity[]", quantity);
				request.getRequestDispatcher("/view/user/orderForm.jsp").forward(request, response);
			} else if (error == null) {
				request.getRequestDispatcher("/view/user/orderConfirm.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/user/userError.jsp").forward(request, response);
			}
		}

	}

}
