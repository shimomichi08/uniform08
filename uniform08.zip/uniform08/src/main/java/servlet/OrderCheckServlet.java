package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/orderCheck")
public class OrderCheckServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		
		//TODO 例外処理を追加する
String error = "";
		
		try {
			response.setContentType("text/html; charset=UTF-8");
			
			String[] uniName = request.getParameterValues("uniName[]");
			String[] uniSize = request.getParameterValues("uniSize[]");
			String[] quantity = request.getParameterValues("quantity[]");
			int uniPrice = Integer.parseInt(request.getParameter("uniPrice"));
			String overview = request.getParameter("overview");
			String email = request.getParameter("email");
			String userName = request.getParameter("userName");
			String address = request.getParameter("address");
			
			ArrayList<Order> orderList = new ArrayList<Order>();
			
			for (int i = 0; i < uniName.length; i++) {
			Order order = new Order();
			order.setUniName(uniName[i]);
			order.setUniSize(uniSize[i]);
			order.setQuantity(Integer.parseInt(quantity[i]));
			order.setUniPrice(uniPrice);
			order.setOverview(overview);
			order.setEmail(email);
			order.setUserName(userName);
			order.setAddress(address);
			orderList.add(order);
			}
			
			//セッションにorderListを登録
			HttpSession session = request.getSession();
			session.setAttribute("orderList", orderList);
			
		}catch(IllegalStateException e) {
			error="DB接続エラーの為、購入は出来ません。";
			request.setAttribute("cmd", "logout");
		
		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/view/user/orderConfirm.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}	
		
			
	}

}
