package servlet;

import java.io.IOException;

import bean.Uniform;
import dao.UniformDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/itemDetail")
public class ItemDetailServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";
		String cmd = "";

		try {

			// uniNo
			int uniNo = Integer.parseInt(request.getParameter("uniNo"));
			cmd = request.getParameter("cmd");
			
			// エンコード　
			request.setCharacterEncoding("UTF-8");

			// オブジェクト生成
			UniformDAO uniformDao = new UniformDAO();

			Uniform uniform = uniformDao.selectByuniNo(uniNo);
			

			// 存在チェック
			if(uniform.getUniNo() == 0) {

				if(cmd.equals("detail")) {
					
					error = "表示対象の書籍が存在しません。";
					cmd = "itemList";
					return;
					
				} else if(cmd.equals("update")) {
					
					error = "更新対象の書籍が存在しません。";
					cmd = "itemList";
					return;
				} // if-else
			} // if
			
			// リクエストスコープに登録
			request.setAttribute("uniform", uniform);

		} catch(IllegalStateException e) {

			if(cmd.equals("detail")) {

				error = "DB接続エラーの為、書籍詳細は表示できませんでした。";
				cmd = "logout";

			} else if(cmd.equals("update")) {

				error = "DB接続エラーの為、変更画面は表示出来ませんでした。";
				cmd = "logout";

			} // if-else
		} finally {

			if(error.equals("")) {

				// cmdの値を判定し、detailの場合はdetail,jspへフォワード
				// updateの場合はupdate.jspへフォワード
				if (cmd.equals("detail")) {

					request.getRequestDispatcher("/view/admin/itemDetail.jsp").forward(request, response);

				}else if(cmd.equals("update")){

					request.getRequestDispatcher("/view/admin/itemUpdate.jsp").forward(request, response);

				} // if-else
				
			} else {

				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/admin/adminError.jsp").forward(request, response);

			} // if-else
		} // finally
	} // doGet
} // class
