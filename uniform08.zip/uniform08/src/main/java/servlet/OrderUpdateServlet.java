package servlet;

import java.io.IOException;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.SendMail;

@WebServlet("/orderUpdate")
public class OrderUpdateServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言と初期化
		String error = "";

		OrderDAO orderObj = new OrderDAO();

		Order order = new Order();

		SendMail sendMail = new SendMail();

		//③エンコード
		request.setCharacterEncoding("UTF-8");

		try {
			//未入力エラー
			if (request.getParameter("title").equals("")) {
				error = "タイトルが未入力の為、書籍更新処理は行えませんでした。";
				return;
			}
			//未入力エラー
			if (request.getParameter("price").equals("")) {
				error = "価格が未入力の為、書籍更新処理は行えませんでした。";
				return;
			}

			//orderNO取得
			int orderNo = Integer.parseInt(request.getParameter("orderNo"));

			order = orderObj.selectByOrderNo(orderNo);
			
			if (order.getOrderNo() == 0) {
				error = "更新対象の書籍が存在しない為、書籍更新処理は行えませんでした。";
				return;
			}

			//画面から取得
			String pay = request.getParameter("pay");
			//書き換え
			orderObj.updatePay(pay, orderNo);

			String send = request.getParameter("send");
			orderObj.updateSend(send, orderNo);

			if (pay.equals("購入済") && (send.equals("未発送"))) {
				//購入済みメール
				sendMail.payEmail(order);

			} else if (pay.equals("購入済") && (send.equals("発送済"))) {
				//発送済みメール
				sendMail.beanEmail(order);
			} else {
				//それ以外
			}

		} catch (

		IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			request.setAttribute("cmd", "logout");

		} finally {
			//エラーがあればエラー画面へ遷移し、なければlist.jspへフォワードする
			if (error.equals("")) {
				request.getRequestDispatcher("/orderList").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
