package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.SendMail;

@WebServlet("/orderUpdate")
public class OrderUpdateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言と初期化
		String error = "";

		OrderDAO orderObj = new OrderDAO();

		Order order = new Order();

		SendMail sendMail = new SendMail();

		//③エンコード
		request.setCharacterEncoding("UTF-8");

		try {
			

			//groupNO取得
			int groupNo = Integer.parseInt(request.getParameter("groupNo"));
			OrderDAO orderDao = new OrderDAO();
			ArrayList<Order> orderList = orderDao.searchGroupNo(groupNo);

			//画面から取得
			String pay = request.getParameter("pay");
			String send = request.getParameter("send");
			if(pay == null) {
				pay = "";
			}
			if(send == null) {
				send = "";
			}
			
			if (pay.equals("はい")) {
				orderObj.updatePay(groupNo);
				//購入済みメール
				int total = 0;
				String mail_detail = "";
				
				for (int i = 0; i < orderList.size(); i++) {
					mail_detail = mail_detail + "\n【商品名】" + orderList.get(i).getUniName() + "\n【サイズ】" + orderList.get(i).getUniSize()
							+ "\n【単価】" + orderList.get(i).getUniPrice()+ "\n【個数】" + orderList.get(i).getQuantity()
							+ "\n【小計】" + (orderList.get(i).getUniPrice()*orderList.get(i).getQuantity()) +"\n";
					total += orderList.get(i).getUniPrice()*orderList.get(i).getQuantity();
					
					if(i == orderList.size()-1) {
						String overview = orderList.get(i).getOverview();
						if(overview == null) {
							overview = "";
						}
						mail_detail = mail_detail + "\n【備考欄】" + overview + "\n";
					}
				}
				
				SendMail sm = new SendMail();
				sm.payEmail(orderList.get(0).getUserName(),mail_detail,total,orderList.get(0).getOrderDate());
			
			}
			if (send.equals("はい")) {
				orderObj.updateSend(groupNo);
				//発送済みメール
				int total = 0;
				String mail_detail = "";
				
				for (int i = 0; i < orderList.size(); i++) { 
					mail_detail = mail_detail + "\n【商品名】" + orderList.get(i).getUniName() + "\n【サイズ】" + orderList.get(i).getUniSize()
							+ "\n【単価】" + orderList.get(i).getUniPrice()+ "\n【個数】" + orderList.get(i).getQuantity()
							+ "\n【小計】" + (orderList.get(i).getUniPrice()*orderList.get(i).getQuantity()) +"\n";
					total += orderList.get(i).getUniPrice()*orderList.get(i).getQuantity();
					
					if(i == orderList.size()-1) {
						String overview = orderList.get(i).getOverview();
						if(overview == null) {
							overview = "";
						}
						mail_detail = mail_detail + "\n【備考欄】" + overview + "\n";
					}
				}
				
				SendMail sm = new SendMail();
				sm.beanEmail(orderList.get(0).getUserName(),mail_detail,total,orderList.get(0).getGroupNo(), orderList.get(0).getOrderDate());
				
			} else {
				//それ以外
			}
			orderList = orderDao.searchGroupNo(groupNo);
			request.setAttribute("orderList", orderList);

		} catch (

		IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			request.setAttribute("cmd", "logout");

		} finally {
			//エラーがあればエラー画面へ遷移し、なければlist.jspへフォワードする
			if (error.equals("")) {
				request.getRequestDispatcher("/view/admin/completeUpdate.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
