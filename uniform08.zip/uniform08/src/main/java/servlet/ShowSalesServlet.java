package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

import bean.Sales;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/showSales")
public class ShowSalesServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言
		String error = null;
		OrderDAO orderDao = new OrderDAO();
		String selectMonth = request.getParameter("month");
		int month;
		ArrayList<Sales> sales_list = new ArrayList<Sales>();
		if (selectMonth.equals("january")) {
			month = 1;
		} else if (selectMonth.equals("february")) {
			month = 2;
		} else if (selectMonth.equals("march")) {
			month = 3;
		} else if (selectMonth.equals("april")) {
			month = 4;
		} else if (selectMonth.equals("may")) {
			month = 5;
		} else if (selectMonth.equals("june")) {
			month = 6;
		} else if (selectMonth.equals("july")) {
			month = 7;
		} else if (selectMonth.equals("august")) {
			month = 8;
		} else if (selectMonth.equals("september")) {
			month = 9;
		} else if (selectMonth.equals("october")) {
			month = 10;
		} else if (selectMonth.equals("november")) {
			month = 11;
		} else {
			month = 12;
		}
		Calendar cal = Calendar.getInstance(); //今日の日付
		Calendar cal2 = Calendar.getInstance(); //閲覧する日付
		cal2.set(Calendar.MONTH, month-1);
		if (cal.before(cal2)) {
			cal2.set(Calendar.YEAR, cal.get(Calendar.YEAR) - 1);
		}
		int year = cal2.get(Calendar.YEAR);
		String strYear=year+"";
		String strMonth=month+"";
		request.setAttribute("strYear", strYear);
		request.setAttribute("strMonth", strMonth);
		try {
			//取得		
			sales_list = orderDao.selectBySales(strYear, strMonth);
			request.setAttribute("salesList", sales_list);
		} catch (IllegalStateException e) {
			error = "接続エラーの為、登録処理は行えませんでした。";
		} finally {
			//詳細画面に遷移
			if (error == null) {
				request.getRequestDispatcher("/view/admin/showSales.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/admin/adminError.jsp").forward(request, response);
			}
		}
	}
}
