package servlet;

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/userInsert")
public class UserInsertServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*エラーメッセージの宣言
		  (error:エラー画面に遷移するエラー、message:登録フォームに戻るエラー)*/
		String error = null;
		String message1 = null;
		String message2 = null;
		String message3 = null;
		String message4 = null;
		String message5 = null;
		int count = 0;

		//　画面からの入力情報を受け取り、userオブジェクトに格納
		String userId = request.getParameter("userId");
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String address = request.getParameter("address");

		//　userDAOとuserクラスのオブジェクトを生成
		UserDAO userDao = new UserDAO();
		User user = null;
		try {

			// ユーザーIDが重複していたら値を返すメソッド
			User userIdAlready = userDao.selectByUser(userId);

			//　エラーの種類によってエラー文と遷移先を指定する
			if ("".equals(userId)) {
				message1 = "ユーザーIDを入力してください";
				request.setAttribute("message1", message1);
				count++;
			} else if (userIdAlready.getUserId() != null) {
				message1 = "このユーザーIDは既に使用されています";
				request.setAttribute("message1", message1);
				request.setAttribute("userId", userId);
				count++;
			} else {
				request.setAttribute("userId", userId);
			}
			if ("".equals(userName)) {
				message2 = "氏名を入力してください";
				request.setAttribute("message2", message2);
				count++;
			} else {
				request.setAttribute("userName", userName);
			}
			if ("".equals(email)) {
				message3 = "メールアドレスを入力してください";
				request.setAttribute("message3", message3);
				count++;
			} else {
				request.setAttribute("userEmail", email);
			}
			if ("".equals(address)) {
				message4 = "住所を入力してください";
				request.setAttribute("message4", message4);
				count++;
			} else {
				request.setAttribute("userAddress", address);
			}
			if ("".equals(password)) {
				message5 = "パスワードを入力してください";
				request.setAttribute("message5", message5);
				count++;
			} else {
				request.setAttribute("userPassword", password);
			}
			if (count > 0) {
				return;
			}

			//　エラーではない場合の正常処理
			user = new User();
			user.setUserId(userId);
			user.setUserName(userName);
			user.setPassword(password);
			user.setEmail(email);
			user.setAddress(address);
			user.setAuthority("一般ユーザー"); //　ここは一般ユーザー権限のみ

			userDao.insertUser(user);

			//　DBが停止している場合の処理
		} catch (IllegalStateException e) {
			error = "接続エラーです。";
		} finally {
			//　エラーではない場合の正常処理
			if (count > 0) {
				request.getRequestDispatcher("/view/user/userInsert.jsp").forward(request, response);
			} else if (error == null) {
				request.getRequestDispatcher("/view/user/userLogin.jsp").forward(request, response);
			} else {
				//　errorとcmdをリクエストスコープに登録
				//　上記のif文でdetailでもupdateでもない場合はerror画面へ遷移
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/user/error.jsp").forward(request, response);
			}
		}
	}

}
