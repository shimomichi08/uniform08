package servlet;

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/userInsert")
public class UserInsertServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{
	//　エラーとコマンドを空文字で初期化
	String error = "";
	String cmd = "";
	try {
		//　userDAOとuserクラスのオブジェクトを生成
		UserDAO userDao = new UserDAO();
		User user = null;

		//　画面からの入力情報を受け取り、userオブジェクトに格納
		String userId = request.getParameter("userId");
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		
		// ユーザーIDが重複していたら値を返すメソッド
		User userIdAlready = userDao.selectByUser(userId);
		
		//　エラーの種類によってエラー文と遷移先を指定する
		if("".equals(userId)) {
			error = "ユーザーIDが未入力の為、書籍登録処理は行えませんでした。";
			cmd = "";
		} else if("".equals(userName)) {
			error = "氏名が未入力の為、書籍登録処理は行えませんでした。";
			cmd = "";
		} else if("".equals(password)) {
			error = "パスワードが未入力の為、書籍登録処理は行えませんでした。";
			cmd = "";
		} else if(userIdAlready.getUserId() != null) {
			error = "入力ユーザーIDは既に存在する為、書籍登録処理は行えませんでした。";
			cmd = "";
		}
		// emailとaddressは登録なしでもOK
		
		//　エラーではない場合の正常処理
		if(error.equals("")) {
			user = new User();
			user.setUserId(userId);
			user.setUserName(userName);
			user.setPassword(password);
			user.setEmail(email);
			user.setAddress(address);
			user.setAuthority("一般ユーザー");	//　ここは一般ユーザー権限のみ
			
			userDao.insertUser(user);
		}
		
	//　DBが停止している場合の処理
	} catch(IllegalStateException e) {
		error = "DB接続エラーの為、会員登録は行えませんでした。";
		cmd = "";
	} finally {
		//　エラーではない場合の正常処理
		if(error.equals("")) {
			request.getRequestDispatcher("").forward(request, response);
		}
		//　errorとcmdをリクエストスコープに登録
		//　上記のif文でdetailでもupdateでもない場合はerror画面へ遷移
		request.setAttribute("error", error);
		request.setAttribute("cmd", cmd);
		request.getRequestDispatcher("").forward(request, response);
	}
}

}
