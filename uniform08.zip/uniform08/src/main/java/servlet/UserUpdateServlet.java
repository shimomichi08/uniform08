package servlet;

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/userUpdate")
public class UserUpdateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String message1 = "";
		String message2 = "";
		String message3 = "";
		String message4 = "";

		int count = 0;
		try {

			// エンコードの設定
			request.setCharacterEncoding("UTF-8");

			// オブジェクト生成
			UserDAO userDao = new UserDAO();

			// セッション
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");
			
			if(user == null){
				//セッション切れならerror.jspへフォワードする
				error = "session";
				return;
			}

			// データの取得 
			String userId = request.getParameter("userId");
			String userName = request.getParameter("userName");
			String address = request.getParameter("address");
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			String authority = request.getParameter("authority");

			// 確認処理
			if(userName.equals("")) {

				message1 = "氏名を入力して下さい。";
				request.setAttribute("message1", message1);
				count++;

			} else {
				request.setAttribute("userName", userName);
			}

			if(address.equals("")) {

				message2 = "住所を入力して下さい。";
				request.setAttribute("message2", message2);
				count++;

			} else {
				request.setAttribute("address", address);
			}

			if(email.equals("")) {

				message3 = "Emailを入力して下さい。";
				request.setAttribute("message3", message3);
				count++;

			} else {
				request.setAttribute("email", email);
			}

			if(password.equals("")) {

				message4 = "パスワードを入力して下さい。";
				request.setAttribute("message4", message4);
				count++;

			} else {
				request.setAttribute("password", password);
			}

			if (count > 0) {
				return;
			} // if

			User user_rec = new User();

			// 取得したデータを設定する
			user_rec.setUserId(userId);
			user_rec.setUserName(userName);
			user_rec.setAddress(address);
			user_rec.setEmail(email);
			user_rec.setPassword(password);
			user_rec.setAuthority(authority);

			// メソッド呼び出し
			userDao.updateUser(user_rec);

		} catch (IllegalStateException e) {

			error = "db";

		} finally {

			if(count > 0) {
				request.getRequestDispatcher("/view/user/userUpdate.jsp").forward(request, response);
			} // if

			if (error.equals("")) {

				request.getRequestDispatcher("/view/user/userMyPage.jsp").forward(request, response);

			} else {

				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/user/userError.jsp").forward(request, response);

			} // if-else
		} // finally
	} // doGet
} // class
