package servlet;

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/userUpdate")
public class UserUpdateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		// エンコードの設定
		request.setCharacterEncoding("UTF-8");		
		
		// オブジェクト生成
		UserDAO userDao = new UserDAO();
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		// データの取得 
		String userId = request.getParameter("userId");
		String userName = request.getParameter("userName");
		String address = request.getParameter("address");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String authority = request.getParameter("authority");
		
		User user_rec = new User();
		
		// 取得したデータを設定する
		user_rec.setUserId(userId);
		user_rec.setUserName(userName);
		user_rec.setAddress(address);
		user_rec.setEmail(email);
		user_rec.setPassword(password);
		user_rec.setAuthority(authority);
		
		// メソッド呼び出し
		userDao.updateUser(user_rec);
		
		request.getRequestDispatcher("/view/user/userMyPage.jsp").forward(request, response);
		
	} // doGet
} // class
