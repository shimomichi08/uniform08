package servlet;

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/userUpdate")
public class UserUpdateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		// エンコードの設定
		request.setCharacterEncoding("UTF-8");
		
		// データの取得
		String userName = request.getParameter("userName");
		String address = request.getParameter("address");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		// オブジェクト生成
		UserDAO userDao = new UserDAO();
		User user = new User();
		
		// 取得したデータを設定する
		user.setUserName(userName);
		user.setAddress(address);
		user.setEmail(email);
		user.setPassword(password);
		
		// メソッド呼び出し
		userDao.updateUser(user);
		
		request.getRequestDispatcher("/view/user/userMyPage.jsp").forward(request, response);
		
	} // doGet
} // class
