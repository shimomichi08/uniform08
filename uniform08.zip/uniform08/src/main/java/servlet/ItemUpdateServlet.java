package servlet;

import java.io.IOException;

import bean.Uniform;
import dao.UniformDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/itemUpdate")
public class ItemUpdateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String error ="";
		
		try {
			//画面からの入力情報を受け取るためのエンコードを設定する
			response.setContentType("text/html; charset=UTF-8");
			
			UniformDAO uniformDao = new UniformDAO();

			//画面からの入力情報を受け取る
			String uniNo=request.getParameter("uniNo");
			String uniName=request.getParameter("uniName");
			String uniSize=request.getParameter("uniSize");
			int uniStock= Integer.parseInt(request.getParameter("uniStock"));
			int uniPrice= Integer.parseInt(request.getParameter("uniPrice"));
			
			Uniform uniform = uniformDao.selectByuniNo(uniNo);
			uniform.setUniName(uniName);
			uniform.setUniSize(uniSize);
			uniform.setUniStock(uniStock);
			uniform.setUniPrice(uniPrice);

			//Bookオブジェクトに格納された書籍データでデータベースを更新する
			uniformDao.update(uniform);
			
		
		}catch(IllegalStateException e) {
			

		}finally {
			if(error.equals("")){
				request.getRequestDispatcher("/itemList").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
		
	}
}