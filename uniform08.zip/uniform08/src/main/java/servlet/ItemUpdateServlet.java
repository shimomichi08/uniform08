package servlet;

import java.io.IOException;

import bean.Uniform;
import dao.UniformDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/itemUpdate")
public class ItemUpdateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		String error ="";
		int count = 0;
		String message1 = null;
		String message2 = null;
		String message3 = null;
		String message4 = null;
		String message5 = null;

		//画面からの入力情報を受け取るためのエンコードを設定する
		response.setContentType("text/html; charset=UTF-8");

		UniformDAO uniformDao = new UniformDAO();

		//画面からの入力情報を受け取る
		int uniNo = Integer.parseInt(request.getParameter("uniNo"));
		String uniName = request.getParameter("uniName");
		String uniSize = request.getParameter("uniSize");
		String stockOld = request.getParameter("uniStock");
		String priceOld = request.getParameter("uniPrice");
		
		try {
			// 入力確認
			if(uniName.equals("")) {
				message1 = "商品名を入力して下さい。";
				request.setAttribute("message1", message1);
				count++;
				
			} else {
				request.setAttribute("uniName", uniName);
			}
			
			if(uniSize.equals("")) {
				message2 = "サイズを入力して下さい。";
				request.setAttribute("message2", message2);
				count++;

			} else {
				request.setAttribute("uniSize", uniSize);
			}
			
			if(stockOld.equals("")) {
				message3 = "在庫数を入力して下さい。";
				request.setAttribute("message3", message3);
				count++;

			} else {
				request.setAttribute("stockOld", stockOld);
			}
			
			if(priceOld.equals("")) {
				message4 = "価格を入力して下さい。";
				request.setAttribute("message4", message4);
				count++;
				
			} else {
				request.setAttribute("priceOld", priceOld);
			}

			if(count > 0) {
				return;
			} // if

			int uniStock = Integer.parseInt(stockOld);
			int uniPrice = Integer.parseInt(priceOld);

			//Uniform uniform = uniformDao.selectByuniNo(uniNo);
			Uniform uniform = new Uniform();
			uniform.setUniNo(uniNo);
			uniform.setUniName(uniName);
			uniform.setUniSize(uniSize);
			uniform.setUniStock(uniStock);
			uniform.setUniPrice(uniPrice);

			//Bookオブジェクトに格納された書籍データでデータベースを更新する
			uniformDao.update(uniform);

		}catch(IllegalStateException e) {

			error = "DB接続エラーの為、更新処理は行えませんでした。";
			request.setAttribute("cmd", "logout");

		}catch(NumberFormatException e) {

			message5 = "在庫数、価格には数値を入力して下さい。";
			count++;
			request.setAttribute("message5", message5);

		}finally {

			if(count > 0) {
				request.getRequestDispatcher("view/admin/itemUpdate.jsp").forward(request, response);
			} // if

			if(error.equals("")){
				request.getRequestDispatcher("/itemList").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/admin/adminError.jsp").forward(request, response);
			}
		}

	}
}