package servlet;

import java.io.IOException;

import bean.Uniform;
import dao.UniformDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/itemUpdate")
public class ItemUpdateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String message2 = null;
		String message3 = null;
		String message4 = null;
		String message5 = null;
		String message6 = null;
		int count = 0;

		try {
			//画面からの入力情報を受け取るためのエンコードを設定する
			response.setContentType("text/html; charset=UTF-8");

			UniformDAO uniformDao = new UniformDAO();

			//画面からの入力情報を受け取る
			String uniNo = request.getParameter("uniNo");
			String uniName = request.getParameter("uniName");
			String uniSize = request.getParameter("uniSize");
			String uniStock = request.getParameter("uniStock");
			String uniPrice = request.getParameter("uniPrice");

			if (uniName.equals("")) {
				message2 = "商品名を入力してください";
				request.setAttribute("message2", message2);
				count++;
			} else {
				request.setAttribute("uniName", uniName);
			}
			if (uniSize.equals("")) {
				message3 = "サイズを入力してください";
				request.setAttribute("message3", message3);
				count++;
			} else {
				request.setAttribute("uniSize", uniSize);
			}
			if (uniStock.equals("")) {
				message4 = "在庫を入力してください";
				request.setAttribute("message4", message4);
				count++;
			} else {
				request.setAttribute("uniStock", uniStock);
			}
			if (uniPrice.equals("")) {
				message5 = "価格を入力してください";
				request.setAttribute("message5", message5);
				count++;
			} else {
				request.setAttribute("uniPrice", uniPrice);
			}
			if (count > 0) {
				return;
			}

			Uniform uniform = uniformDao.selectByuniNo(uniNo);
			uniform.setUniName(uniName);
			uniform.setUniSize(uniSize);
			uniform.setUniStock(Integer.parseInt(uniStock));
			uniform.setUniPrice(Integer.parseInt(uniPrice));

			//Bookオブジェクトに格納された書籍データでデータベースを更新する
			uniformDao.update(uniform);

		} catch (IllegalStateException e) {
			error="接続エラーです。";
		} catch (NumberFormatException e) {
			message6 = "在庫、価格には数値を入力してください";
			count++;
			request.setAttribute("message6", message6);
		} finally {
			if(count>0) {
				request.getRequestDispatcher("/view/admin/itemUpdate.jsp").forward(request, response);
			}else if (error.equals("")) {
				request.getRequestDispatcher("/itemList").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/admin/error.jsp").forward(request, response);
			}
		}

	}
}