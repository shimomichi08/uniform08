package servlet;

import java.io.IOException;

import bean.Uniform;
import dao.UniformDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/itemInsert")
public class ItemInsertServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*エラーメッセージの宣言
		  (error:エラー画面に遷移するエラー、message:登録フォームに戻るエラー)*/
		String error = null;
		String message2=null;
		String message3=null;
		String message4=null;
		String message5=null;
		String message6=null;
		
		int count = 0;
		UniformDAO uniformDao = new UniformDAO();
		//入力値取得
		Uniform uniform = new Uniform();
		String uniName = request.getParameter("name");
		String uniSize = request.getParameter("size");
		String uniStock = request.getParameter("stock");
		String uniPrice = request.getParameter("price");
		try {
			//入力値確認
			if (uniName.equals("")) {
				message2 = "商品名を入力してください";
				request.setAttribute("message2", message2);
				count++;
			} else {
				request.setAttribute("uniName", uniName);
			}
			if (uniSize.equals("")) {
				message3 = "サイズを入力してください";
				request.setAttribute("message3", message3);
				count++;
			} else {
				request.setAttribute("uniSize", uniSize);
			}
			if (uniStock.equals("")) {
				message4 = "在庫を入力してください";
				request.setAttribute("message4", message4);
				count++;
			} else {
				request.setAttribute("uniStock", uniStock);
			}
			if (uniPrice.equals("")) {
				message5 = "価格を入力してください";
				request.setAttribute("message5", message5);
				count++;
			} else {
				request.setAttribute("uniPrice", uniPrice);
			}
			if (count > 0) {
				return;
			}
			//入力値をuniformに格納
			uniform.setUniName(uniName);
			uniform.setUniSize(uniSize);
			uniform.setUniStock(Integer.parseInt(uniStock));
			uniform.setUniPrice(Integer.parseInt(uniPrice));
			//登録処理			
			uniformDao.insert(uniform);
		} catch (IllegalStateException e) {
			error = "接続エラーの為、登録処理は行えませんでした。";
			request.setAttribute("cmd", "logout");
		} catch (NumberFormatException e) {
			message6 = "商品番号、在庫、価格には数値を入力してください";
			count++;
			request.setAttribute("message6", message6);
		} finally {
			//詳細画面に遷移
			if(count>0) {
				request.getRequestDispatcher("/view/admin/itemInsert.jsp").forward(request, response);
			}
			if (error == null) {
				request.getRequestDispatcher("/itemList").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/admin/adminError.jsp").forward(request, response);
			}
		}
	}
}
