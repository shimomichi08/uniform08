package servlet;

import java.io.IOException;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/orderDetail")
public class OrderDetailServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージの宣言
		String error = null;
		OrderDAO orderDao = new OrderDAO();
		int orderNo = Integer.parseInt(request.getParameter("orderNo"));
		try {
			//詳細情報を取得する
			Order order = orderDao.showOrderDetail(orderNo);
			//取得した詳細情報をリクエストスコープに登録
			request.setAttribute("orderDetail", order);
		} catch (IllegalStateException e) {
			error = "接続エラーの為、詳細表示は行えませんでした。";
			request.setAttribute("cmd", "logout");
		} finally {
			//詳細画面に遷移
			if (error == null) {
				request.getRequestDispatcher("/view/admin/orderDetail.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/admin/adminError.jsp").forward(request, response);
			}
		}
	}
}
