package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import bean.User;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/showOrderedItemServlet")
public class ShowOrderedItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{
		
		//　エラーとコマンドを空文字で初期化
		String error = "";
		String cmd = "";

		try {
		
			OrderDAO orderDao = new OrderDAO();
			ArrayList<Order> orderedList = new ArrayList<Order>();
			
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");
			String email = user.getEmail();
		
			orderedList = orderDao.selectByUser(email);
		
			//　取得したlistをリクエストスコープに登録
			request.setAttribute("ordered_list", orderedList);

		} catch(IllegalStateException e) {
			error = "DB接続エラーの為、購入状況確認は出来ません。";
			cmd = "logout";
		} finally {
			if(error.equals("")) {
				// showOrderedItemにフォワード処理
				request.getRequestDispatcher("/view/user/showOrderedItem.jsp").forward(request,response);
				return;
			} else {
				request.setAttribute("error",error);
				request.setAttribute("cmd",cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
