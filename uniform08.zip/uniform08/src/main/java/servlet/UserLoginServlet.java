package servlet;

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/userLogin")
public class UserLoginServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String message0 = null;
		String message1 = null;
		String message2 = null;
		String message3 = null;

		try {

			// データの取得
			String userId = request.getParameter("userId");
			String password = request.getParameter("password");
			if (userId.equals("")) {
				message1 = "ユーザーIDを入力してください";
				request.setAttribute("message1", message1);
			}
			if (password.equals("")) {
				message2 = "パスワードを入力してください";
				request.setAttribute("message2", message2);
			}
			if (message1 != null || message2 != null) {
				return;
			}
			
			// エンコードの設定
			request.setCharacterEncoding("UTF-8");

			// UserDAOオブジェクト生成
			UserDAO userDao = new UserDAO();

			// メソッドを呼び出す
			User user = userDao.selectByUser(userId, password);
			
			if(user.getUserId()==null) {
				// Userがない場合
				message0 = "ユーザーIDもしくはパスワードが間違っています！";
				request.setAttribute("message0", message0);
				return;
			} // else
			if(user.getAuthority().equals("管理者")) {
				
				message3 = "ログインできません。";
				request.setAttribute("message3", message3);
				return;
			}
			
			// ログイン情報
			if (userId.equals(user.getUserId())) {

				// Userがある場合
				// セッションスコープ
				HttpSession session = request.getSession();
				session.setAttribute("user", user);

				// クッキーに入力情報を登録する(期間は5日)
				// ユーザー用クッキーの生成
				Cookie userCookie = new Cookie("userId", userId);
				userCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(userCookie);

				// パスワード用クッキーの生成
				Cookie passCookie = new Cookie("password", password);
				passCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(passCookie);
			}
		} catch (IllegalStateException e) {

			error = "db";
		} finally {
			if (message0 != null || message1 != null || message2 != null || message3 != null) {
				request.getRequestDispatcher("/view/user/userLogin.jsp").forward(request, response);
			}
			if (error.equals("")) {
				request.getRequestDispatcher("/view/user/userMyPage.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/user/userError.jsp").forward(request, response);
			} // if
		} // finally
	} // doPost
}
// class
